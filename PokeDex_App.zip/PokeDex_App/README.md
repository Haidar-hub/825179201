# pokeDeX app

 project Flutter 

pembuatan pokedex pokemon sebagai tugas pertama mobile programming

825179201/Muhammad.Farhan Haidar